#!/usr/bin/env bash

echo "Foo!"
